<?php
class RsaKeysUtil {
    const PRIVATE_KEY = "SYSTEM_PRIVATE_KEY";
    const PUBLIC_KEY = "PUBLIC_KEY";

    public static function decryptData($encryptedData, $privateKeyPem) {
        $chunks = explode('.', $encryptedData);
        $decrypted = '';
        foreach ($chunks as $chunk) {
            openssl_private_decrypt(base64_decode($chunk), $output, $privateKeyPem, OPENSSL_PKCS1_PADDING);
            $decrypted .= $output;
        }
        return $decrypted;
    }

    public static function verifySignature($publicKeyPem, $data, $signatureBase64) {
        return openssl_verify(trim($data), base64_decode($signatureBase64), $publicKeyPem, OPENSSL_ALGO_SHA256) === 1;
    }

    public static function sign($payload, $privateKeyPem) {
        openssl_sign($payload, $signature, $privateKeyPem, OPENSSL_ALGO_SHA256);
        return base64_encode($signature);
    }

  public static function encryptData($data, $publicKeyPem) {
        $key = openssl_pkey_get_public($publicKeyPem);
        $keyDetails = openssl_pkey_get_details($key);
        $keySizeBytes = $keyDetails['bits'] / 8;
        $hashSizeBytes = 32;
        $maxChunkSize = $keySizeBytes - 2 * ($hashSizeBytes - 2);

        $chunks = str_split($data, $maxChunkSize);
        $encryptedChunks = [];

        foreach ($chunks as $chunk) {
            openssl_public_encrypt($chunk, $encrypted, $publicKeyPem, OPENSSL_PKCS1_PADDING);
            $encryptedChunks[] = base64_encode($encrypted);
        }

        return implode('.', $encryptedChunks);
    }
}
?>
