const crypto = require('crypto');

const RsaKeysUtil = {
    PRIVATE_KEY: 'SYSTEM_PRIVATE_KEY',
    PUBLIC_KEY: 'PUBLIC_KEY',

    decryptData(encryptedData, privateKeyPem) {
        const privateKey = crypto.createPrivateKey(privateKeyPem);
        const chunks = encryptedData.split('.');
        const decryptedChunks = chunks.map(chunk => {
            const buffer = Buffer.from(chunk, 'base64');
            return crypto.privateDecrypt(
                {
                    key: privateKey,
                    padding: crypto.constants.RSA_PKCS1_PADDING,
                },
                buffer
            ).toString('utf8');
        });
        return decryptedChunks.join('');
    },

    verifySignature(publicKeyPem, data, signatureBase64) {
        const verifier = crypto.createVerify('SHA256');
        verifier.update(data.replace(/\s/g, ''));
        verifier.end();
        return verifier.verify(publicKeyPem, signatureBase64.replace(/\s/g, ''), 'base64');
    },

    getPublicKeyFromPem(publicKeyPem) {
        return crypto.createPublicKey(publicKeyPem);
    },

    sign(payload, privateKeyPem) {
        const signer = crypto.createSign('SHA256');
        signer.update(payload);
        signer.end();
        const signature = signer.sign(privateKeyPem);
        return signature.toString('base64');
    },

    encryptData(payload, publicKeyPem) {
        const publicKey = crypto.createPublicKey(publicKeyPem);
        const buffer = Buffer.from(payload);
        const keySizeBytes = publicKey.asymmetricKeyDetails.modulusLength / 8;
        const hashSizeBytes = 32; // SHA-256
        const maxChunkSize = keySizeBytes - 2 * (hashSizeBytes - 2);
        const encryptedChunks = [];

        for (let i = 0; i < buffer.length; i += maxChunkSize) {
            const chunk = buffer.slice(i, i + maxChunkSize);
            const encryptedChunk = crypto.publicEncrypt(
                {
                    key: publicKey,
                    padding: crypto.constants.RSA_PKCS1_PADDING,
                },
                chunk
            );
            encryptedChunks.push(encryptedChunk.toString('base64'));
        }

        return encryptedChunks.join('.');
    }
};

module.exports = RsaKeysUtil;