import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.Cipher;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.interfaces.RSAPrivateKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;


public class RsaKeysUtil {

	public final static String SYSTEM_PRIVATE_KEY = "SYSTEM_PRIVATE_KEY"

	public final static String SYSTEM_PUBLIC_KEY = "SYSTEM_PUBLIC_KEY"

	static {
		Security.addProvider(new BouncyCastleProvider());
	}

	public static String decryptData ( String encryptedData , PrivateKey privateKey ) throws Exception {
		String[] encryptedChunks = encryptedData.split("\\.");
		StringBuilder decryptedText = new StringBuilder();

		for (String chunk : encryptedChunks) {
			Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding" , "BC");
			cipher.init(Cipher.DECRYPT_MODE , privateKey);
			byte[] decodedChunk = Base64.getDecoder().decode(chunk);
			byte[] decryptedChunk = cipher.doFinal(decodedChunk);
			decryptedText.append(new String(decryptedChunk , StandardCharsets.UTF_8));
		}

		return decryptedText.toString();
	}

	public static RSAPrivateKey getPrivateKeyFromString ( String privateKey ) throws Exception {
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");

		String keyPEM = privateKey
				.replace("-----BEGIN RSA PRIVATE KEY-----" , "")
				.replace("-----END RSA PRIVATE KEY-----" , "")
				.replaceAll("\\s" , "");

		byte[] decoded = Base64.getDecoder().decode(keyPEM);


		PKCS8EncodedKeySpec keySpec =
				new PKCS8EncodedKeySpec(decoded);
		return (RSAPrivateKey) keyFactory.generatePrivate(keySpec);

	}

	public static boolean verifySignature ( String publicKeyStr , String encryptedData , String signatureBase64 ) {
		try {
			Security.addProvider(new BouncyCastleProvider());
			PublicKey publicKey = getPublicKeyFromPem(publicKeyStr);
			byte[] signatureBytes = Base64.getDecoder().decode(signatureBase64.replaceAll(" " , ""));
			Signature signature = Signature.getInstance("SHA256withRSA");
			signature.initVerify(publicKey);
			signature.update(encryptedData.replaceAll(" " , "").getBytes(StandardCharsets.UTF_8));
			return signature.verify(signatureBytes);
		} catch (Exception e) {
			System.out.println("Exception while verifying signature: " + e.getMessage());
			return false;
		}
	}

	public static PublicKey getPublicKeyFromPem ( String publicKey ) throws Exception {
		String publicKeyPEM = publicKey
				.replace("-----BEGIN PUBLIC KEY-----" , "")
				.replace("-----END PUBLIC KEY-----" , "")
				.replaceAll("\\s" , "");

		byte[] keyBytes = Base64.getDecoder().decode(publicKeyPEM);
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(keyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		return keyFactory.generatePublic(keySpec);
	}


	public static String sign ( String payload , PrivateKey privateKey ) throws Exception {
		Signature signature = Signature.getInstance("SHA256withRSA");
		signature.initSign(privateKey);
		signature.update(payload.getBytes(StandardCharsets.UTF_8));
		byte[] signatureBytes = signature.sign();
		return Base64.getEncoder().encodeToString(signatureBytes);
	}

	public static String encryptData ( String payload , String publicKeyStr ) throws Exception {
		// Parse the PEM public key
		String publicKeyPEM = publicKeyStr
				.replace("-----BEGIN PUBLIC KEY-----" , "")
				.replace("-----END PUBLIC KEY-----" , "")
				.replaceAll("\\s+" , "");
		byte[] publicKeyBytes = Base64.getDecoder().decode(publicKeyPEM);
		X509EncodedKeySpec spec = new X509EncodedKeySpec(publicKeyBytes);
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
		PublicKey publicKey = keyFactory.generatePublic(spec);

		// Determine key size and max chunk size
		int keySizeBytes = publicKey.getEncoded().length; // Key size in bytes
		int hashSizeBytes = 32; // SHA-256 hash size in bytes
		int maxChunkSize = keySizeBytes - 2 * (hashSizeBytes - 2);

		// Encrypt in chunks
		Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
		cipher.init(Cipher.ENCRYPT_MODE , publicKey);
		List<String> encryptedChunks = new ArrayList<>();

		for (int i = 0; i < payload.length(); i += maxChunkSize) {
			int end = Math.min(i + maxChunkSize , payload.length());
			String chunk = payload.substring(i , end);
			byte[] encryptedChunk = cipher.doFinal(chunk.getBytes());
			encryptedChunks.add(java.util.Base64.getEncoder().encodeToString(encryptedChunk));
		}

		// Join chunks with a delimiter
		return String.join("." , encryptedChunks);
	}
}